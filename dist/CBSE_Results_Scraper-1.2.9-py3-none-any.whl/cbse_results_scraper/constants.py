# String to test result occurrence
Text = "Result Not Found"

# Alphabet dictionary for brute-force attacking student's initial and mother's initial
Alphabet = (
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
)

# Versions of results
Original = "http://cbseresults.nic.in/class12/Class12th19.htm"
Revised = "http://cbseresults.nic.in/class12-Revised/Class12th19_revised.htm"
Compartment = "http://cbseresults.nic.in/class12-Compt/Class12th19_Compt.htm"